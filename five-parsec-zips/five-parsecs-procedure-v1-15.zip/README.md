# Five Parsecs Procedure V1.15

This package contains the full file listings for the procedure-driven Five Parsecs prototype.

## V1.15 changes

- Replaced the temporary made-up crew type tables with the crew creation table data supplied in `crewCreationTables.js`.
- Kept the interactive table command behavior from V1.14:
  - show the full table
  - allow physical dice by letting the player select any row
  - allow app dice to highlight a row
  - save the selected result
  - push follow-up table commands onto the top of the queue
- Crew Type can now branch to the supplied Primary Alien or Strange Character subtables.

## Install

Copy the `src` folder contents into your project, replacing the matching files.
