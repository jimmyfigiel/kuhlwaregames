// src/games/five-parsecs-procedure/data/nameSets/index.js
export { sciFiNames } from "./scifiNames.js";
