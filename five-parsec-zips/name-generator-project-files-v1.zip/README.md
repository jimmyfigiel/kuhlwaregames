# Procedure Core Name Generator Files

Add these files to the project to introduce a reusable Markov-style name generator and a Five Parsecs-specific sci-fi name seed list.

Files:

- `src/procedure-core/name-generator/MarkovNameGenerator.js`
- `src/procedure-core/name-generator/index.js`
- `src/games/five-parsecs-procedure/data/nameSets/scifiNames.js`
- `src/games/five-parsecs-procedure/data/nameSets/index.js`

Example usage:

```js
import { MarkovNameGenerator } from "../../../procedure-core/name-generator";
import { sciFiNames } from "../data/nameSets";

const generator = new MarkovNameGenerator({ sci_fi: sciFiNames });
const randomName = generator.generateName("sci_fi");
```

The generator belongs to `procedure-core`; the actual name list belongs to the game module.
