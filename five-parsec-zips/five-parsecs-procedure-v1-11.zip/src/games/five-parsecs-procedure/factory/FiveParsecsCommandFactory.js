import { CommandFactory } from "../../../procedure-core/factory";
import { BuildStartingCrewCommand, CrewMemberNameCommand } from "../commands";

export default class FiveParsecsCommandFactory extends CommandFactory {
  buildStartingCrew({
    id,
    title = "Build Starting Crew",
    crewCountPath = "crewLog.startingCrewCount",
    pauseAfter = false,
    visible = false,
  }) {
    return new BuildStartingCrewCommand({
      id,
      title,
      crewCountPath,
      pauseAfter,
      visible,
    });
  }

  crewMemberName({
    id,
    crewMemberNumber = 1,
    title = null,
    prompt = null,
    defaultValue = "",
    buttonText = "OK",
    allowRandomName = true,
    randomNameSet = "sci_fi",
    randomNameButtonText = "Generate Name",
    pauseAfter = false,
  }) {
    return new CrewMemberNameCommand({
      id,
      crewMemberNumber,
      title,
      prompt,
      defaultValue,
      buttonText,
      allowRandomName,
      randomNameSet,
      randomNameButtonText,
      pauseAfter,
    });
  }

  fromJSON(commandData) {
    const coreCommand = super.fromJSON(commandData);

    if (coreCommand) {
      return coreCommand;
    }

    if (!commandData || !commandData.type) {
      return null;
    }

    switch (commandData.type) {
      case "buildStartingCrew":
        return new BuildStartingCrewCommand(commandData);

      case "crewMemberName":
        return new CrewMemberNameCommand(commandData);

      default:
        console.warn(`Unknown command type: ${commandData.type}`);
        return null;
    }
  }
}
