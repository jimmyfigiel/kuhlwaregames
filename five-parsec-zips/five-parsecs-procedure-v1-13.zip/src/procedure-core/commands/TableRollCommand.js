import BaseCommand from "./BaseCommand";
import { removeUndefinedValues } from "../utils";

function normalizeEntry(entry) {
  if (!entry || typeof entry !== "object") {
    return null;
  }

  const min = Number(entry.min ?? entry.roll ?? 0);
  const max = Number(entry.max ?? entry.roll ?? min);

  if (!Number.isFinite(min) || !Number.isFinite(max)) {
    return null;
  }

  return removeUndefinedValues({
    ...entry,
    min,
    max,
  });
}

function rollDie(sides) {
  return Math.floor(Math.random() * sides) + 1;
}

function findResult(table, roll) {
  const entries = Array.isArray(table?.entries) ? table.entries : [];

  return (
    entries
      .map(normalizeEntry)
      .filter(Boolean)
      .find((entry) => roll >= entry.min && roll <= entry.max) || null
  );
}

export default class TableRollCommand extends BaseCommand {
  constructor({
    id,
    title = "Roll on Table",
    table = null,
    roll = null,
    result = null,
    saveTo = null,
    buttonText = "OK",
    status = "pending",
    pauseAfter = false,
    visible = true,
  }) {
    super({
      id,
      type: "tableRoll",
      title,
      status,
      pauseAfter,
      visible,
    });

    this.table = table || {
      id: "unknown-table",
      title: "Unknown Table",
      dice: "d100",
      sides: 100,
      entries: [],
    };
    this.roll = roll;
    this.result = result;
    this.saveTo = saveTo;
    this.buttonText = buttonText;
  }

  execute(engineContext) {
    const sides = Number(this.table?.sides || 100);
    const safeSides = Number.isFinite(sides) && sides > 0 ? Math.floor(sides) : 100;
    const nextRoll = this.roll ?? rollDie(safeSides);
    const nextResult = this.result || findResult(this.table, nextRoll);

    this.roll = nextRoll;
    this.result = nextResult || {
      label: "No result",
      description: `No table entry matched roll ${nextRoll}.`,
    };
    this.status = "waitingForUser";

    engineContext.showActiveCommand(this);
    engineContext.setStatus("waitingForUser");
    engineContext.stopAfterCurrentCommand();

    engineContext.addLogEntry({
      type: "commandStarted",
      text: `Rolled ${nextRoll} on ${this.table?.title || this.title}: ${this.result.label}`,
      commandId: this.id,
    });
  }

  resolve(engineContext) {
    if (this.saveTo) {
      engineContext.setStateValue(
        this.saveTo,
        removeUndefinedValues({
          tableId: this.table?.id,
          tableTitle: this.table?.title,
          roll: this.roll,
          label: this.result?.label,
          value: this.result?.value,
          description: this.result?.description,
        })
      );
    }

    const followUpCommands = Array.isArray(this.result?.followUpCommands)
      ? this.result.followUpCommands
      : [];

    if (followUpCommands.length > 0) {
      engineContext.pushCommandsToTop(followUpCommands);
    }

    this.status = "complete";
    engineContext.clearActiveCommand();
    engineContext.setStatus("idle");

    engineContext.addLogEntry({
      type: "commandCompleted",
      text: `Completed table roll: ${this.table?.title || this.title} → ${this.result?.label || "No result"}`,
      commandId: this.id,
    });
  }

  toJSON() {
    return removeUndefinedValues({
      ...super.toJSON(),
      table: this.table,
      roll: this.roll,
      result: this.result,
      saveTo: this.saveTo,
      buttonText: this.buttonText,
    });
  }
}
