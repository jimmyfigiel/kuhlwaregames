# Five Parsecs Procedure V1.12

This package updates the crew-member random-name button to use the pulpy Five Parsecs-specific Markov seed list by default.

## Key behavior

- Crew-member name prompts still allow manual entry.
- The Generate Name button now uses `pulpyFiveParsecsNames`.
- The reusable Markov generator remains in `src/procedure-core/name-generator/`.
- The name data remains game-specific under `src/games/five-parsecs-procedure/data/nameSets/`.

## Default name set id

```js
five_parsecs_pulp
```
