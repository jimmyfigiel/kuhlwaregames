function makeTableRollCommand({ id, title, table, saveTo }) {
  return {
    id,
    type: "tableRoll",
    title,
    table,
    saveTo,
    buttonText: "OK",
    pauseAfter: false,
    visible: true,
  };
}

export const primaryAlienTable = {
  id: "five-parsecs-primary-alien-test",
  title: "Primary Alien Type",
  dice: "d100",
  sides: 100,
  note: "Starter/test table for the procedure engine. Replace with your owned campaign table if desired.",
  entries: [
    {
      min: 1,
      max: 20,
      label: "Frontier Adapted",
      value: "frontierAdapted",
      description: "A practical alien from a rough colony world.",
    },
    {
      min: 21,
      max: 40,
      label: "Void-Touched",
      value: "voidTouched",
      description: "A traveler whose people are comfortable in ships, stations, and deep space.",
    },
    {
      min: 41,
      max: 60,
      label: "Warrior Caste",
      value: "warriorCaste",
      description: "A member of a hard-edged martial culture.",
    },
    {
      min: 61,
      max: 80,
      label: "Machine Symbiote",
      value: "machineSymbiote",
      description: "An organic being with an unusually close bond to technology.",
    },
    {
      min: 81,
      max: 100,
      label: "Ancient Lineage",
      value: "ancientLineage",
      description: "A descendant of an old culture with strange customs and long memories.",
    },
  ],
};

export const strangeCharacterTable = {
  id: "five-parsecs-strange-character-test",
  title: "Strange Character Type",
  dice: "d100",
  sides: 100,
  note: "Starter/test table for the procedure engine. Replace with your owned campaign table if desired.",
  entries: [
    {
      min: 1,
      max: 20,
      label: "Clone Survivor",
      value: "cloneSurvivor",
      description: "A duplicate who outlived the reason they were made.",
    },
    {
      min: 21,
      max: 40,
      label: "Time-Lost Drifter",
      value: "timeLostDrifter",
      description: "Someone displaced from another era, timeline, or long-forgotten stasis pod.",
    },
    {
      min: 41,
      max: 60,
      label: "Mutant Outcast",
      value: "mutantOutcast",
      description: "A changed human or near-human used to surviving on the margins.",
    },
    {
      min: 61,
      max: 80,
      label: "Synthetic Soul",
      value: "syntheticSoul",
      description: "An artificial person with more personality than their maker intended.",
    },
    {
      min: 81,
      max: 100,
      label: "Mystic Wanderer",
      value: "mysticWanderer",
      description: "A strange traveler guided by visions, rumors, or something worse.",
    },
  ],
};

export function buildCrewTypeTableForCrewMember({ crewMemberId, crewMemberNumber }) {
  const detailBasePath = `crewLog.crewDetails.${crewMemberId}`;

  return {
    id: "five-parsecs-crew-type-test",
    title: "Crew Type",
    dice: "d100",
    sides: 100,
    note: "Starter/test table for the procedure engine. Replace with your owned campaign table if desired.",
    entries: [
      {
        min: 1,
        max: 55,
        label: "Human",
        value: "human",
        description: "A standard human crew member from the fringes of known space.",
      },
      {
        min: 56,
        max: 75,
        label: "Primary Alien",
        value: "primaryAlien",
        description: "Roll on the Primary Alien table next.",
        followUpCommands: [
          makeTableRollCommand({
            id: `crew-member-${crewMemberNumber}-primary-alien-table`,
            title: `Crew Member ${crewMemberNumber}: Primary Alien`,
            table: primaryAlienTable,
            saveTo: `${detailBasePath}.primaryAlien`,
          }),
        ],
      },
      {
        min: 76,
        max: 90,
        label: "Bot / Synthetic",
        value: "botSynthetic",
        description: "A robot, synthetic, or machine-person suitable for a frontier crew.",
      },
      {
        min: 91,
        max: 100,
        label: "Strange Character",
        value: "strangeCharacter",
        description: "Roll on the Strange Character table next.",
        followUpCommands: [
          makeTableRollCommand({
            id: `crew-member-${crewMemberNumber}-strange-character-table`,
            title: `Crew Member ${crewMemberNumber}: Strange Character`,
            table: strangeCharacterTable,
            saveTo: `${detailBasePath}.strangeCharacter`,
          }),
        ],
      },
    ],
  };
}
