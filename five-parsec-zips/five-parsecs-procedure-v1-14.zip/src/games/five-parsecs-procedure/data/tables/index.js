export {
  buildCrewTypeTableForCrewMember,
  primaryAlienTable,
  strangeCharacterTable,
} from "./crewTypeTables";
