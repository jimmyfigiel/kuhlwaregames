# Five Parsecs Procedure Engine V1.17

This package is a full-listings update for the procedure-driven Five Parsecs prototype.

## New in V1.17

Table selections now trigger explicit game-specific update commands.

The generic `TableRollCommand` still owns the reusable table behavior:

1. show the full table
2. allow app dice roll
3. allow the player to select any row
4. save the selected result
5. push follow-up commands

Five Parsecs now adds a game-specific command:

```text
UpdateCrewMemberFromTableResultCommand
```

That command reads the saved table result and updates the crew member record.

## Current character flow

```text
Enter crew member name
→ Crew Type table
→ Apply Crew Type result
→ possible Primary Alien / Strange Character subtable
→ Apply subtable result
→ Background / Motivation / Class tables as needed
→ Apply each table result
→ Finalize crew member
```

## What the update command currently applies

The update command now records/applies:

- selected table result history
- starting/base stats from crew type profiles
- max stats from crew type profiles
- stat modifiers from Background, Motivation, and Class
- resources listed by table results
- starting equipment roll requests listed by table results
- profile/category information
- visible notes from selected results

This is still intentionally incremental. The next layer can turn the collected resources and starting roll requests into their own command sequences.
