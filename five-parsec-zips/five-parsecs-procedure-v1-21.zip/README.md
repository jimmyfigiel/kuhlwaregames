# Five Parsecs Procedure Engine V1.18

This package continues the procedure-command build.

## Main changes

- Added a reusable core `UpdateStateCommand`.
- Table selections are now saved through `UpdateStateCommand` instead of directly mutating state inside `TableRollCommand`.
- Crew member name entry now queues a generic update command to save the name before continuing to the crew type table.
- Crew member table effects are no longer applied by a Five Parsecs-specific update command. Instead:
  1. the table command saves the selected row through `UpdateStateCommand`,
  2. a Five Parsecs queue-builder command reads that selected row,
  3. the Five Parsecs factory creates generic update-state commands,
  4. the generic update-state commands apply the actual state updates.
- Added a superuser-only stack inspector to the Five Parsecs view.

## New core files

```text
src/procedure-core/commands/UpdateStateCommand.js
```

## New Five Parsecs files

```text
src/games/five-parsecs-procedure/commands/QueueCrewMemberTableResultUpdateCommandsCommand.js
src/games/five-parsecs-procedure/effects/crewMemberTableResultUpdates.js
src/games/five-parsecs-procedure/effects/index.js
```

## Removed / retired file

```text
src/games/five-parsecs-procedure/commands/UpdateCrewMemberFromTableResultCommand.js
```

If your project already has this old file, delete it after applying this package.

## Superuser stack inspector

When the loaded player has either:

```js
player.isSuperuser === true
```

or:

```js
player.isSuperUser === true
```

then the Five Parsecs queue manager shows a **Stack Inspector** button next to the steps-left display.

It displays:

- queue status
- active command
- pending command count
- full JSON for the active command
- full JSON for every pending command in the queue

## Current design rule

Game-specific logic should create command sequences. State changes should be performed by generic update-state commands whenever possible.


## v1.19 stack inspector visibility fix

The stack inspector is still intended for superusers, but this build also shows it when the game view does not receive a `player` prop. That makes the missing prop visible in the UI instead of silently hiding the inspector.

Visibility rules:

- show when `player.isSuperuser` is true
- show when `player.isSuperUser` is true
- show when a debug flag such as `gameState.debugShowStackInspector`, `gameState.showStackInspector`, or `gameState.debugMode` is true
- show when the `player` prop is missing, with an explanation in the inspector

## V1.20 stack inspector tab

Superusers can open the stack inspector in its own browser tab from the **Stack Inspector** button in the queue manager. The separate tab is driven by the main game view and receives live updates whenever the room/game state changes in the active page. This keeps the implementation simple and avoids adding a separate app route yet.
