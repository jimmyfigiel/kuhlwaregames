# Pulpy Five Parsecs Name Set

This package adds a new Five Parsecs-specific Markov seed list with a more pulpy space-adventure tone.

Suggested destination:

```text
src/games/five-parsecs-procedure/data/nameSets/pulpyFiveParsecsNames.js
```

To use it instead of the previous sci-fi set, import `pulpyFiveParsecsNames` in the game's name-set index or view/factory code and pass it to the shared Markov generator.

The list is intentionally game-specific. The reusable Markov generator should remain in:

```text
src/procedure-core/name-generator/
```
