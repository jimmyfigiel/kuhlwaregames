# Five Parsecs Procedure Engine V1.16

This package extends the V1.15 command queue prototype with the next character-creation tables.

## Added

- Background table data
- Motivation table data
- Class table data
- Character creation table builders
- Finalize crew member command

## Behavior

After a crew member name is entered:

1. The Crew Type table is shown.
2. If the result is Primary Alien, the Primary Alien subtable is pushed onto the top of the queue.
3. If the result is Strange Character, the Strange Character subtable is pushed onto the top of the queue.
4. Based on the final character profile, the needed Background, Motivation, and Class table commands are pushed onto the top of the queue.
5. The crew member is finalized silently.
6. The queue returns to the next crew member name command.

The table command remains generic: it shows the full table, allows app dice, allows physical dice with manual selection, saves the selected result, and pushes any result-provided follow-up commands.
